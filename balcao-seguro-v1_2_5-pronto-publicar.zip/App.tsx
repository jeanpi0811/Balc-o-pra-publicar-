import React, { useEffect, useState } from 'react';
import { StatusBar } from 'react-native';
import { theme } from './src/styles/theme';
import { HomeScreen } from './src/screens/HomeScreen';
import { AtendimentoScreen } from './src/screens/AtendimentoScreen';
import { TriagemScreen } from './src/screens/TriagemScreen';
import { MedicamentosScreen } from './src/screens/MedicamentosScreen';
import { InteracoesScreen } from './src/screens/InteracoesScreen';
import { TrocaSeguraScreen } from './src/screens/TrocaSeguraScreen';
import { RegistroScreen } from './src/screens/RegistroScreen';
import { MaisScreen } from './src/screens/MaisScreen';
import { InfoScreen } from './src/screens/InfoScreen';
import { PremiumScreen } from './src/screens/PremiumScreen';
import { DevScreen } from './src/screens/DevScreen';
import { carregarRegistros, limparRegistros, salvarRegistros } from './src/storage/registros';
import { RegistroAtendimento } from './src/types';
import { ScreenName } from './src/navigation';
import { AceiteInicialScreen } from './src/screens/AceiteInicialScreen';
import { AceiteTermos, carregarAceiteTermos, salvarAceiteTermos } from './src/storage/termos';
import { ativarPremiumDev, ativarPremiumPorCodigo, carregarPremium, desativarPremiumLocal, PremiumState, registrarConsultaCompleta, statusPremium, zerarConsultasGratis } from './src/storage/premium';

export default function App() {
  const [screen, setScreen] = useState<ScreenName>('home');
  const [registros, setRegistros] = useState<RegistroAtendimento[]>([]);
  const [carregado, setCarregado] = useState(false);
  const [aceiteTermos, setAceiteTermos] = useState<AceiteTermos | null>(null);
  const [aceiteCarregado, setAceiteCarregado] = useState(false);
  const [premium, setPremium] = useState<PremiumState>({ ativo: false, consultasUsadas: 0 });

  useEffect(() => {
    carregarRegistros().then((dados) => {
      setRegistros(dados);
      setCarregado(true);
    });

    carregarAceiteTermos().then((aceite) => {
      setAceiteTermos(aceite);
      setAceiteCarregado(true);
    });

    carregarPremium().then(setPremium);
  }, []);

  async function adicionarRegistro(registro: RegistroAtendimento) {
    const novos = [registro, ...registros];
    setRegistros(novos);
    await salvarRegistros(novos);
    setScreen('registro');
  }

  async function removerRegistros() {
    setRegistros([]);
    await limparRegistros();
  }

  async function aceitarTermos() {
    const aceite = await salvarAceiteTermos();
    setAceiteTermos(aceite);
    setScreen('home');
  }

  async function usarConsultaCompleta() {
    const resultado = await registrarConsultaCompleta(premium);
    setPremium(resultado.estado);
    return resultado.permitido;
  }

  async function ativarCodigoPremium(codigo: string) {
    const resultado = await ativarPremiumPorCodigo(codigo, premium);
    setPremium(resultado.estado);
    return resultado;
  }

  async function ativarPremiumModoDev() {
    const novo = await ativarPremiumDev(premium);
    setPremium(novo);
  }

  async function desativarPremiumModoLocal() {
    const novo = await desativarPremiumLocal(premium);
    setPremium(novo);
  }

  async function zerarConsultasGratisLocal() {
    const novo = await zerarConsultasGratis(premium);
    setPremium(novo);
  }

  const premiumStatus = statusPremium(premium);

  if (!aceiteCarregado) {
    return <StatusBar barStyle="light-content" backgroundColor={theme.colors.bg} />;
  }

  if (!aceiteTermos) {
    return (
      <>
        <StatusBar barStyle="light-content" backgroundColor={theme.colors.bg} />
        <AceiteInicialScreen onAceitar={aceitarTermos} />
      </>
    );
  }

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor={theme.colors.bg} />
      {screen === 'home' && <HomeScreen onNavigate={setScreen} totalRegistros={registros.length} activeScreen={screen} />}
      {screen === 'atendimento' && <AtendimentoScreen onNavigate={setScreen} totalRegistros={registros.length} activeScreen={screen} />}
      {screen === 'triagem' && <TriagemScreen onNavigate={setScreen} onSalvarRegistro={adicionarRegistro} activeScreen={screen} />}
      {screen === 'medicamentos' && <MedicamentosScreen onNavigate={setScreen} activeScreen={screen} premiumStatus={premiumStatus} onUsarConsultaCompleta={usarConsultaCompleta} />}
      {screen === 'interacoes' && <InteracoesScreen onNavigate={setScreen} activeScreen={screen} premiumStatus={premiumStatus} onUsarConsultaCompleta={usarConsultaCompleta} />}
      {screen === 'troca' && <TrocaSeguraScreen onNavigate={setScreen} activeScreen={screen} />}
      {screen === 'registro' && <RegistroScreen onNavigate={setScreen} registros={registros} onLimpar={removerRegistros} carregado={carregado} activeScreen={screen} />}
      {screen === 'mais' && <MaisScreen onNavigate={setScreen} totalRegistros={registros.length} activeScreen={screen} />}
      {screen === 'sobre' && <InfoScreen tipo="sobre" onNavigate={setScreen} activeScreen={screen} />}
      {screen === 'termos' && <InfoScreen tipo="termos" onNavigate={setScreen} activeScreen={screen} />}
      {screen === 'privacidade' && <InfoScreen tipo="privacidade" onNavigate={setScreen} activeScreen={screen} />}
      {screen === 'fontes' && <InfoScreen tipo="fontes" onNavigate={setScreen} activeScreen={screen} />}
      {screen === 'premium' && <PremiumScreen onNavigate={setScreen} activeScreen={screen} premiumStatus={premiumStatus} onAtivarCodigo={ativarCodigoPremium} />}
      {screen === 'dev' && <DevScreen onNavigate={setScreen} activeScreen={screen} premium={premium} premiumStatus={premiumStatus} onAtivarDev={ativarPremiumModoDev} onDesativarPremium={desativarPremiumModoLocal} onZerarConsultas={zerarConsultasGratisLocal} />}
    </>
  );
}
