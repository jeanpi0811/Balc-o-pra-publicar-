#!/bin/bash
set -e
cd "$(dirname "$0")"
./GERAR_APK_FINAL.command
