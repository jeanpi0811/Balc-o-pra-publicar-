# Como colocar o Balcão Seguro no GitHub e gerar APK/AAB

O projeto já vem com um workflow pronto em `.github/workflows/main.yml`,
chamado **"Gerar APK Release Sem Servidor"**. Ele compila o APK (pra
instalar direto no celular) e o AAB (pra subir na Play Store) sozinho,
sem precisar de Mac nem Android Studio.

## Passo 1 — Subir o projeto pro GitHub

1. Crie um repositório novo no GitHub (pode ser **Private**).
2. Extraia este ZIP.
3. Envie **o conteúdo de dentro da pasta** `balcao-seguro-github-pronto`
   pro repositório (não o ZIP fechado).
4. Confirme que foram enviados: `package.json`, `App.tsx`, `src/`,
   `assets/` e `.github/workflows/main.yml`.

Pelo terminal:

```bash
cd caminho/para/balcao-seguro-github-pronto
git init
git branch -M main
git add .
git commit -m "Balcao Seguro v1.2.5"
git remote add origin https://github.com/SEU_USUARIO/balcao-seguro.git
git push -u origin main
```

## Passo 2 — Configurar os 4 Secrets (obrigatório antes de publicar)

Sem isso o workflow ainda funciona, mas gera uma keystore *temporária*
diferente a cada execução — ótimo pra teste, mas a Play Store rejeita
atualizações assinadas com chaves diferentes. Configure antes de gerar
o AAB definitivo.

No repositório: **Settings → Secrets and variables → Actions → New
repository secret**. Crie estes 4, com esses nomes exatos:

| Nome do secret | Valor |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | conteúdo do arquivo `keystore_base64.txt` |
| `ANDROID_KEYSTORE_PASSWORD` | a senha da sua keystore |
| `ANDROID_KEY_ALIAS` | `balcao_seguro_upload` |
| `ANDROID_KEY_PASSWORD` | a mesma senha da keystore |

(Se você ainda não tem uma keystore definitiva, peça pro Claude gerar
uma — ele te dá o `.keystore`, o `keystore_base64.txt` e os 4 valores
prontos pra colar aqui.)

## Passo 3 — Rodar o workflow

1. Vá na aba **Actions** do repositório.
2. Abra **"Gerar APK Release Sem Servidor"**.
3. Clique em **Run workflow** (ou apenas dê `git push` em `main`/`master`,
   ele dispara sozinho).
4. Aguarde terminar (uns 10–15 min, ele instala tudo do zero).

## Passo 4 — Baixar os arquivos gerados

No final da execução, em **Artifacts**:

- **Balcao-Seguro-AAB-Play-Store** → contém o `.aab`, é o que você
  sobe no Google Play Console.
- **Balcao-Seguro-APK-Release-Sem-Servidor** → contém o `.apk`, pra
  instalar e testar direto num Android físico.

## Observação sobre instalação no Android

Se o Android reclamar de assinatura ao atualizar uma versão anterior,
é porque o APK antigo foi assinado com outra keystore. Configurando os
secrets do Passo 2 uma vez só, isso não volta a acontecer — toda build
seguinte usa a mesma chave.

## Se o build falhar

Abra o log da execução em **Actions** → clique no run que falhou → veja
qual passo (step) quebrou. Os passos de validação de TypeScript e da
base de medicamentos são non-blocking (`|| true`), então normalmente
quem derruba o build é a etapa **"Compilar APK e AAB release"** —
copie o erro de lá se precisar de ajuda.
