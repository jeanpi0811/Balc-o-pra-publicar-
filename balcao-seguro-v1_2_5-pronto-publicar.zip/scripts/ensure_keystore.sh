#!/bin/bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
ANDROID_DIR="$ROOT_DIR/android"
SIGNING_DIR="$ROOT_DIR/signing"
ROOT_PROP_FILE="$SIGNING_DIR/balcao-seguro-keystore.properties"
ANDROID_PROP_FILE="$ANDROID_DIR/balcao-seguro-keystore.properties"
KEYSTORE_FILE="$SIGNING_DIR/balcao-seguro-upload-key.keystore"
ALIAS="balcao_seguro_upload"

if [ ! -d "$ANDROID_DIR" ]; then
  echo "ERRO: pasta android/ não existe. Rode prebuild primeiro."
  exit 1
fi
mkdir -p "$SIGNING_DIR"

if [ -f "$ROOT_PROP_FILE" ] && [ -f "$KEYSTORE_FILE" ]; then
  cp "$ROOT_PROP_FILE" "$ANDROID_PROP_FILE"
  chmod 600 "$ANDROID_PROP_FILE" || true
  echo "OK: keystore release já existe em signing/ e foi sincronizada."
  exit 0
fi

if [ -f "$KEYSTORE_FILE" ] && [ ! -f "$ROOT_PROP_FILE" ]; then
  echo "Keystore já existe em signing/, mas falta o arquivo de propriedades."
  echo "Digite a mesma senha usada quando ela foi criada. Ela NÃO aparecerá na tela."
  read -s -p "Senha da keystore: " STORE_PASS
  echo ""
  if [ -z "$STORE_PASS" ]; then
    echo "ERRO: senha vazia não permitida."
    exit 1
  fi
else
  echo "============================================"
  echo " Criar chave de assinatura release"
  echo "============================================"
  echo "Esta chave é importante. Guarde backup do arquivo:"
  echo "$KEYSTORE_FILE"
  echo ""
  echo "Digite uma senha NOVA para a chave. Ela NÃO aparecerá na tela."
  echo "Use no mínimo 6 caracteres. Exemplo de formato: NomeApp2026"
  read -s -p "Senha da keystore: " STORE_PASS
  echo ""
  read -s -p "Repita a senha: " STORE_PASS2
  echo ""

  if [ "$STORE_PASS" != "$STORE_PASS2" ]; then
    echo "ERRO: senhas diferentes."
    exit 1
  fi
  if [ ${#STORE_PASS} -lt 6 ]; then
    echo "ERRO: a senha precisa ter no mínimo 6 caracteres."
    exit 1
  fi
  if ! command -v keytool >/dev/null 2>&1; then
    echo "ERRO: keytool não encontrado. Instale JDK 17."
    exit 1
  fi

  keytool -genkeypair \
    -v \
    -storetype PKCS12 \
    -keystore "$KEYSTORE_FILE" \
    -alias "$ALIAS" \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -storepass "$STORE_PASS" \
    -keypass "$STORE_PASS" \
    -dname "CN=Jean Pierre Andres, OU=CRF-RS 15974, O=Balcao Seguro, L=Passo Fundo, ST=RS, C=BR"
fi

cat > "$ROOT_PROP_FILE" <<EOF
storeFile=../signing/balcao-seguro-upload-key.keystore
storePassword=$STORE_PASS
keyAlias=$ALIAS
keyPassword=$STORE_PASS
EOF
chmod 600 "$ROOT_PROP_FILE" || true
cp "$ROOT_PROP_FILE" "$ANDROID_PROP_FILE"
chmod 600 "$ANDROID_PROP_FILE" || true

echo ""
echo "OK: chave criada/configurada."
echo "IMPORTANTE: faça backup da pasta signing/ e NÃO envie essa pasta para GitHub."
