#!/bin/bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
SIGNING_DIR="$ROOT_DIR/signing"
mkdir -p "$SIGNING_DIR"
OLD_KEY="$ROOT_DIR/android/app/balcao-seguro-upload-key.keystore"
NEW_KEY="$SIGNING_DIR/balcao-seguro-upload-key.keystore"
OLD_PROP="$ROOT_DIR/android/balcao-seguro-keystore.properties"
NEW_PROP="$SIGNING_DIR/balcao-seguro-keystore.properties"

if [ -f "$OLD_KEY" ] && [ ! -f "$NEW_KEY" ]; then
  cp "$OLD_KEY" "$NEW_KEY"
  chmod 600 "$NEW_KEY" || true
  echo "OK: keystore antiga preservada em signing/."
fi
if [ -f "$OLD_PROP" ] && [ ! -f "$NEW_PROP" ]; then
  cp "$OLD_PROP" "$NEW_PROP"
  chmod 600 "$NEW_PROP" || true
  echo "OK: propriedades antigas preservadas em signing/."
fi
