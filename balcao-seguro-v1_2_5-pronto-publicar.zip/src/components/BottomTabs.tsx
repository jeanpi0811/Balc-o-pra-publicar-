import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { AppTab, ScreenName } from '../navigation';
import { theme } from '../styles/theme';

type Props = {
  active: AppTab;
  onNavigate: (screen: ScreenName) => void;
};

const tabs: { id: AppTab; screen: ScreenName; label: string; icon: string }[] = [
  { id: 'home', screen: 'home', label: 'Início', icon: '🏚️' },
  { id: 'atendimento', screen: 'atendimento', label: 'Atendimento', icon: '🧑‍💼🎧' },
  { id: 'medicamentos', screen: 'medicamentos', label: 'Medicamentos', icon: '💊' },
  { id: 'interacoes', screen: 'interacoes', label: 'Interações', icon: '⚠️' },
  { id: 'mais', screen: 'mais', label: 'Mais', icon: '•••' },
  { id: 'premium', screen: 'premium', label: 'Premium', icon: '◆' }
];

export function BottomTabs({ active, onNavigate }: Props) {
  return (
    <View style={styles.wrap}>
      {tabs.map((tab) => {
        const selected = tab.id === active;
        return (
          <Pressable key={tab.id} onPress={() => onNavigate(tab.screen)} style={({ pressed }) => [styles.item, selected && styles.selected, pressed && styles.pressed]}>
            <Text style={[styles.icon, selected && styles.selectedText]}>{tab.icon}</Text>
            <Text style={[styles.label, selected && styles.selectedText]} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.62}>{tab.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    flexDirection: 'row',
    backgroundColor: theme.colors.card,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: theme.colors.border,
    padding: 4
  },
  item: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingVertical: 8, borderRadius: 18 },
  selected: { backgroundColor: 'rgba(56, 189, 248, 0.16)', borderWidth: 1, borderColor: 'rgba(56, 189, 248, 0.35)' },
  pressed: { opacity: 0.7 },
  icon: { color: theme.colors.muted, fontWeight: '900', fontSize: 13, lineHeight: 17 },
  label: { color: theme.colors.muted, fontSize: 8.5, fontWeight: '800', marginTop: 2, width: '100%', textAlign: 'center' },
  selectedText: { color: theme.colors.primary }
});
