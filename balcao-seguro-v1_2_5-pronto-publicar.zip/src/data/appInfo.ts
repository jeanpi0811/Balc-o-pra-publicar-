export const appInfo = {
  nome: 'Balcão Seguro',
  slogan: 'Atendimento farmacêutico offline, didático, organizado e preparado para publicação.',
  versao: '1.2.5',
  pacote: 'br.com.farmabolso.balcaoseguro',
  contatoSuporte: 'WhatsApp (54) 99142-7519',
  responsavelFarmaceutico: 'Jean Pierre Andres',
  registroProfissional: 'CRF/RS 15974',
  responsabilidade: 'Responsável pelo conteúdo farmacêutico e curadoria inicial do app. O app é ferramenta de apoio informativo: não realiza diagnóstico, não prescreve e não substitui responsabilidade técnica, protocolos locais, bula ou avaliação presencial quando necessária.',
  bancoMedicamentos: 'Base local offline ultra-ampliada com 5200 medicamentos/substâncias/termos de busca farmacêuticos para triagem, grupos especiais, interações, efeitos adversos, resumo leigo, fontes e pendências de validação. Itens não substituem bula profissional do produto específico.',
  ultimaAtualizacaoBase: '2026-06-28 — v1.2.5: Home com fundo liquid glass animado; Área do Desenvolvedor oculta (acesso restrito) e preparação Apple/Google Billing via RevenueCat',
  coletaDados: 'Não envia dados para servidores. Registros ficam salvos somente no aparelho, salvo compartilhamento manual pelo usuário.',
  publicoAlvo: 'Uso de apoio por profissional habilitado no atendimento farmacêutico.',
};
