import { Medicamento } from '../types';

function normalizar(valor: string): string {
  return valor.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim();
}

function camposEnriquecidos(medicamento: Medicamento): string[] {
  const e = medicamento.enriquecimento;
  if (!e) return [];
  const grupos = e.grupos_especiais;
  return [
    e.uso_orientativo.para_que_serve,
    e.uso_orientativo.indicacao_geral,
    e.uso_orientativo.observacao_nao_prescritiva,
    e.resumo_leigo.para_que_serve,
    e.resumo_leigo.quando_ter_cuidado,
    e.resumo_leigo.quando_procurar_atendimento,
    e.resumo_leigo.o_que_nao_fazer,
    ...e.resumo_leigo.perguntas_do_farmaceutico,
    ...e.formas,
    ...e.vias,
    ...e.concentracoes,
    ...e.alertas.contraindicacoes,
    ...e.alertas.cuidados,
    ...e.alertas.sinais_alerta,
    ...e.alertas.quando_encaminhar,
    ...e.triagem_farmaceutica.perguntas_obrigatorias,
    ...e.triagem_farmaceutica.perguntas_recomendadas,
    ...e.triagem_farmaceutica.criterios_encaminhamento,
    ...e.efeitos_adversos.comuns,
    ...e.efeitos_adversos.importantes,
    ...e.efeitos_adversos.alergia,
    ...e.efeitos_adversos.intoxicacao,
    ...e.efeitos_adversos.atendimento_imediato,
    ...e.interacoes.flatMap((i) => [i.com, i.classe_ou_medicamento, i.gravidade, i.mecanismo_simples, i.consequencia, i.orientacao_segura, i.fonte]),
    ...Object.entries(grupos).flatMap(([chave, valor]) => [chave, valor.classificacao, valor.observacao]),
    ...e.fontes.flatMap((fonte) => [fonte.nome, fonte.url ?? '', fonte.resumo_usado, fonte.nivel_confianca]),
    ...e.status_validacao.pendencias,
    e.status_validacao.observacoes,
    e.aviso_responsabilidade
  ];
}

export function buscarMedicamentos(medicamentos: Medicamento[], termo: string): Medicamento[] {
  const q = normalizar(termo); if (!q) return medicamentos;
  return medicamentos.filter((medicamento) => {
    const campos = [
      medicamento.nome,
      medicamento.principioAtivo,
      medicamento.classe,
      medicamento.tarja,
      medicamento.forma,
      medicamento.dosagem,
      medicamento.referencia ?? '',
      medicamento.numeroRegistroAnvisa ?? '',
      medicamento.situacaoRegistro ?? '',
      medicamento.categoriaRegulatoria ?? '',
      medicamento.detentorRegistro ?? '',
      medicamento.revisadoPor ?? '',
      medicamento.statusValidacao ?? '',
      medicamento.escopoValidacao ?? '',
      medicamento.revisaoVenceEm ?? '',
      ...(medicamento.perguntasChave ?? []),
      ...(medicamento.sinaisAlertaBalcao ?? []),
      ...(medicamento.quandoEncaminhar ?? []),
      ...(medicamento.genericos ?? []),
      ...(medicamento.similaresIntercambiaveis ?? []),
      ...medicamento.alertas,
      ...medicamento.contraindicacoes,
      ...(medicamento.observacoesValidacao ?? []),
      ...(medicamento.fontes ?? []).flatMap((fonte) => [fonte.tipo, fonte.titulo, fonte.observacao ?? '']),
      ...camposEnriquecidos(medicamento)
    ];
    return campos.some((campo) => normalizar(campo).includes(q));
  });
}
