import React, { useEffect, useRef } from 'react';
import { Animated, Easing, StyleSheet, Text, View } from 'react-native';
import { ActionTile } from '../components/ActionTile';
import { BottomTabs } from '../components/BottomTabs';
import { Card } from '../components/Card';
import { Header } from '../components/Header';
import { Screen } from '../components/Screen';
import { Body, Muted, Subtitle } from '../components/TextBits';
import { appInfo } from '../data/appInfo';
import { contarStatusValidacao } from '../data/baseMedicamentosInfo';
import { medicamentos } from '../data/medicamentos';
import { protocolos } from '../data/protocolos';
import { ScreenName, tabFromScreen } from '../navigation';
import { theme } from '../styles/theme';

type Props = {
  onNavigate: (screen: ScreenName) => void;
  totalRegistros: number;
  activeScreen: ScreenName;
};

export function HomeScreen({ onNavigate, totalRegistros, activeScreen }: Props) {
  const statusBase = contarStatusValidacao(medicamentos);
  const liquidFloat = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const animation = Animated.loop(
      Animated.sequence([
        Animated.timing(liquidFloat, {
          toValue: 1,
          duration: 5200,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
        Animated.timing(liquidFloat, {
          toValue: 0,
          duration: 5200,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ])
    );

    animation.start();
    return () => animation.stop();
  }, [liquidFloat]);

  return (
    <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
      <HomeLiquidGlassBackground progress={liquidFloat} />
      <Header subtitle="Atendimento farmacêutico com mais clareza, segurança e registro local." />

      <ActionTile icon="＋" title="Novo atendimento" body="Comece pelo perfil do paciente, siga a triagem e salve o registro." onPress={() => onNavigate('atendimento')} tone="green" />
      <ActionTile icon="🔎" title="Buscar medicamento" body="Consulte princípio ativo, alertas, contraindicações e status da base." onPress={() => onNavigate('medicamentos')} />
      <ActionTile icon="⚠️" title="Interações medicamentosas" body="Faça uma checagem inicial entre dois medicamentos e veja os cuidados." onPress={() => onNavigate('interacoes')} tone="yellow" />

      <Card>
        <Subtitle>Resumo rápido</Subtitle>
        <View style={styles.statsRow}>
          <Stat label="Protocolos" value={`${protocolos.length}`} />
          <Stat label="Medicamentos" value={`${medicamentos.length}`} />
          <Stat label="Registros" value={`${totalRegistros}`} />
        </View>
        <Muted>Base local: {statusBase.validado} validado(s), {statusBase.pre_validado} pré-validados, {statusBase.parcial} parciais e {statusBase.pendente} pendentes.</Muted>
      </Card>

      <Card>
        <Subtitle>Fluxo recomendado</Subtitle>
        <Step n="1" text="Identifique faixa etária e riscos do paciente." />
        <Step n="2" text="Use triagem guiada para sinais de alerta." />
        <Step n="3" text="Consulte medicamento, interação e possibilidade de troca." />
        <Step n="4" text="Registre a orientação e encaminhe quando necessário." />
      </Card>

      <Card>
        <Subtitle>Responsável pelo conteúdo</Subtitle>
        <Body>{appInfo.responsavelFarmaceutico} — {appInfo.registroProfissional}</Body>
        <Muted>Uso profissional de apoio. Não substitui julgamento farmacêutico, bula, protocolos locais ou atendimento médico quando indicado.</Muted>
      </Card>
    </Screen>
  );
}


function HomeLiquidGlassBackground({ progress }: { progress: Animated.Value }) {
  const floatUp = progress.interpolate({ inputRange: [0, 1], outputRange: [0, -16] });
  const floatDown = progress.interpolate({ inputRange: [0, 1], outputRange: [0, 14] });
  const softPulse = progress.interpolate({ inputRange: [0, 1], outputRange: [0.58, 0.88] });
  const rotate = progress.interpolate({ inputRange: [0, 1], outputRange: ['-10deg', '8deg'] });

  return (
    <View pointerEvents="none" style={styles.liquidLayer}>
      <Animated.View style={[styles.liquidBlob, styles.blobPrimary, { opacity: softPulse, transform: [{ translateY: floatUp }, { rotate }] }]} />
      <Animated.View style={[styles.liquidBlob, styles.blobSecondary, { transform: [{ translateY: floatDown }] }]} />
      <Animated.View style={[styles.liquidRing, { opacity: softPulse, transform: [{ translateY: floatDown }] }]} />
      <Animated.Text
        style={[
          styles.watermarkGlyph,
          {
            opacity: softPulse,
            transform: [{ translateY: floatUp }, { rotate }],
          },
        ]}
      >
        🛡️
      </Animated.Text>
      <Animated.Text
        style={[
          styles.watermarkGlyphSmall,
          {
            opacity: softPulse,
            transform: [{ translateY: floatDown }],
          },
        ]}
      >
        💊
      </Animated.Text>
    </View>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.stat}>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

function Step({ n, text }: { n: string; text: string }) {
  return (
    <View style={styles.step}>
      <Text style={styles.stepBadge}>{n}</Text>
      <Text style={styles.stepText}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  liquidLayer: {
    position: 'absolute',
    top: -70,
    left: -30,
    right: -30,
    height: 520,
    overflow: 'hidden',
  },
  liquidBlob: {
    position: 'absolute',
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(125, 211, 252, 0.28)',
  },
  blobPrimary: {
    width: 300,
    height: 300,
    right: -108,
    top: 16,
    backgroundColor: 'rgba(56, 189, 248, 0.12)',
  },
  blobSecondary: {
    width: 220,
    height: 220,
    left: -84,
    top: 210,
    backgroundColor: 'rgba(34, 197, 94, 0.08)',
    borderColor: 'rgba(34, 197, 94, 0.20)',
  },
  liquidRing: {
    position: 'absolute',
    width: 190,
    height: 190,
    borderRadius: 95,
    right: 30,
    top: 260,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.16)',
    backgroundColor: 'rgba(255, 255, 255, 0.035)',
  },
  watermarkGlyph: {
    position: 'absolute',
    right: -30,
    top: 60,
    fontSize: 220,
    lineHeight: 260,
    color: theme.colors.primary,
  },
  watermarkGlyphSmall: {
    position: 'absolute',
    right: 150,
    top: 300,
    fontSize: 90,
    lineHeight: 108,
    color: theme.colors.green,
  },
  statsRow: { flexDirection: 'row', gap: theme.spacing.sm, marginBottom: theme.spacing.md },
  stat: { flex: 1, backgroundColor: theme.colors.card2, borderRadius: theme.radius.md, padding: theme.spacing.sm, borderWidth: 1, borderColor: theme.colors.border },
  statValue: { color: theme.colors.primary, fontSize: 20, fontWeight: '900', textAlign: 'center' },
  statLabel: { color: theme.colors.muted, fontSize: 11, textAlign: 'center', marginTop: 2 },
  step: { flexDirection: 'row', alignItems: 'center', marginTop: 10 },
  stepBadge: { width: 26, height: 26, borderRadius: 13, overflow: 'hidden', textAlign: 'center', lineHeight: 26, color: theme.colors.bg, backgroundColor: theme.colors.primary, fontWeight: '900', marginRight: 10 },
  stepText: { color: theme.colors.text, flex: 1, lineHeight: 20 }
});
