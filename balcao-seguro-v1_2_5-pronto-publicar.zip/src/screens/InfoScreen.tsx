import React, { useRef } from 'react';
import { Pressable, Text, StyleSheet, View } from 'react-native';
import { BottomTabs } from '../components/BottomTabs';
import { Card } from '../components/Card';
import { PrimaryButton } from '../components/PrimaryButton';
import { Screen } from '../components/Screen';
import { Body, Muted, Subtitle, Title } from '../components/TextBits';
import { appInfo } from '../data/appInfo';
import { avisosSeguranca, declaracoesAceite, fontesDados, politicaPrivacidade, termosAceiteInicial, termosUso } from '../data/legal';
import { contarStatusValidacao } from '../data/baseMedicamentosInfo';
import { medicamentos, totalMedicamentosEnriquecidos } from '../data/medicamentos';
import { protocolos } from '../data/protocolos';
import { ScreenName, tabFromScreen } from '../navigation';
import { theme } from '../styles/theme';

type Props = {
  tipo: 'sobre' | 'termos' | 'privacidade' | 'fontes';
  onNavigate: (screen: ScreenName) => void;
  activeScreen: ScreenName;
};

export function InfoScreen({ tipo, onNavigate, activeScreen }: Props) {
  const statusBase = contarStatusValidacao(medicamentos);
  const toquesVersao = useRef(0);

  function tocarVersao() {
    toquesVersao.current += 1;
    if (toquesVersao.current >= 7) {
      toquesVersao.current = 0;
      onNavigate('dev');
    }
  }

  if (tipo === 'sobre') {
    return (
      <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
        <Title>Sobre o app</Title>
        <Card>
          <Subtitle>{appInfo.nome}</Subtitle>
          <Body>{appInfo.slogan}</Body>
          <View style={styles.metaBox}>
            <Pressable onPress={tocarVersao}>
              <Meta label="Versão" value={appInfo.versao} />
            </Pressable>
            <Meta label="Pacote" value={appInfo.pacote} />
            <Meta label="Responsável" value={`${appInfo.responsavelFarmaceutico} — ${appInfo.registroProfissional}`} />
            <Meta label="Protocolos" value={`${protocolos.length}`} />
            <Meta label="Medicamentos locais" value={`${medicamentos.length}`} />
            <Meta label="Base enriquecida" value={`${totalMedicamentosEnriquecidos}`} />
            <Meta label="Base validada/parcial/pendente" value={`${statusBase.validado}/${statusBase.parcial}/${statusBase.pendente}`} />
            <Meta label="Suporte" value={appInfo.contatoSuporte} />
          </View>
        </Card>
        <Card>
          <Subtitle>Escopo de uso</Subtitle>
          <Body>{appInfo.publicoAlvo}</Body>
          <Muted>Organiza atendimento, perfil do paciente, triagem, medicamentos, interações e registros locais.</Muted>
        </Card>
        <Card>
          <Subtitle>Faixa etária e perfil</Subtitle>
          <Body>Em cada novo atendimento, selecione adulto, criança, idoso, gestante ou lactante e marque fatores de risco. Esses dados entram no registro salvo.</Body>
        </Card>
        <Card>
          <Subtitle>Responsabilidade profissional</Subtitle>
          <Body>{appInfo.responsabilidade}</Body>
        </Card>
        <ListCard title="Avisos de segurança" items={avisosSeguranca} />
        <PrimaryButton title="Voltar para Mais" onPress={() => onNavigate('mais')} variant="secondary" />
      </Screen>
    );
  }

  if (tipo === 'termos') {
    return (
      <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
        <Title>Termos de uso</Title>
        <Muted>Texto inicial para uso interno/testes. Revise juridicamente antes de publicação comercial.</Muted>
        <ListCard title="Termos exibidos na primeira abertura" items={termosAceiteInicial} />
        <ListCard title="Declarações obrigatórias de aceite" items={declaracoesAceite} />
        <ListCard title="Condições complementares" items={termosUso} />
        <PrimaryButton title="Voltar para Mais" onPress={() => onNavigate('mais')} variant="secondary" />
      </Screen>
    );
  }

  if (tipo === 'privacidade') {
    return (
      <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
        <Title>Privacidade</Title>
        <Muted>{appInfo.coletaDados}</Muted>
        <ListCard title="Política desta versão" items={politicaPrivacidade} />
        <PrimaryButton title="Voltar para Mais" onPress={() => onNavigate('mais')} variant="secondary" />
      </Screen>
    );
  }

  return (
    <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
      <Title>Fontes e base local</Title>
      <Muted>Última atualização informada da base: {appInfo.ultimaAtualizacaoBase}</Muted>
      <Card>
        <Subtitle>Resumo da base</Subtitle>
        <Body>{appInfo.bancoMedicamentos}</Body>
        <View style={styles.metaBox}>
          <Meta label="Validados" value={`${statusBase.validado}`} />
          <Meta label="Pré-validados" value={`${statusBase.pre_validado}`} />
          <Meta label="Parciais" value={`${statusBase.parcial}`} />
          <Meta label="Pendentes" value={`${statusBase.pendente}`} />
          <Meta label="Desatualizados" value={`${statusBase.desatualizado}`} />
          <Meta label="Enriquecidos" value={`${totalMedicamentosEnriquecidos}`} />
        </View>
      </Card>
      <ListCard title="Origem dos dados" items={fontesDados} />
      <PrimaryButton title="Voltar para Mais" onPress={() => onNavigate('mais')} variant="secondary" />
    </Screen>
  );
}

function ListCard({ title, items }: { title: string; items: string[] }) {
  return (
    <Card>
      <Subtitle>{title}</Subtitle>
      {items.map((item, index) => <Text key={`${title}-${index}`} style={styles.item}>• {item}</Text>)}
    </Card>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.metaRow}>
      <Text style={styles.metaLabel}>{label}</Text>
      <Text style={styles.metaValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  item: { color: theme.colors.muted, lineHeight: 21, marginBottom: 6 },
  metaBox: { marginTop: 12, gap: 7 },
  metaRow: { flexDirection: 'row', gap: 10, justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: theme.colors.border, paddingBottom: 6 },
  metaLabel: { color: theme.colors.muted, fontWeight: '700', flex: 1 },
  metaValue: { color: theme.colors.text, flex: 2, textAlign: 'right' }
});
