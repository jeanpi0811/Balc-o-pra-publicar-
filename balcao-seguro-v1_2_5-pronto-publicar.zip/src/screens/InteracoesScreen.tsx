import React, { useMemo, useState } from 'react';
import { Alert, StyleSheet, Text, TextInput, View } from 'react-native';
import { BottomTabs } from '../components/BottomTabs';
import { Card } from '../components/Card';
import { PrimaryButton } from '../components/PrimaryButton';
import { Screen } from '../components/Screen';
import { Body, Muted, Subtitle, Title } from '../components/TextBits';
import { medicamentos } from '../data/medicamentos';
import { buscarMedicamentos } from '../logic/buscaMedicamentos';
import { avaliarInteracao } from '../logic/interacoes';
import { ScreenName, tabFromScreen } from '../navigation';
import { theme } from '../styles/theme';
import { Medicamento } from '../types';
import { PremiumStatus } from '../storage/premium';

type Props = { onNavigate: (screen: ScreenName) => void; activeScreen: ScreenName; premiumStatus: PremiumStatus; onUsarConsultaCompleta: () => Promise<boolean> };

export function InteracoesScreen({ onNavigate, activeScreen, premiumStatus, onUsarConsultaCompleta }: Props) {
  const [termoA, setTermoA] = useState('');
  const [termoB, setTermoB] = useState('');
  const medA = useMemo(() => termoA.trim() ? buscarMedicamentos(medicamentos, termoA)[0] : undefined, [termoA]);
  const medB = useMemo(() => termoB.trim() ? buscarMedicamentos(medicamentos, termoB)[0] : undefined, [termoB]);
  const resultado = medA && medB ? avaliarInteracao(medA, medB) : undefined;
  const parAtual = medA && medB ? `${medA.id}|${medB.id}` : '';
  const [parLiberado, setParLiberado] = useState('');
  const resultadoLiberado = Boolean(resultado && parAtual && parLiberado === parAtual);

  async function liberarResultado() {
    if (!resultado || !parAtual) return;
    const permitido = await onUsarConsultaCompleta();
    if (!permitido) {
      Alert.alert(
        'Limite gratuito atingido',
        'Você usou suas 3 consultas completas gratuitas. Assine o Premium para liberar checagens ilimitadas.',
        [
          { text: 'Agora não', style: 'cancel' },
          { text: 'Ver Premium', onPress: () => onNavigate('premium') },
        ]
      );
      return;
    }
    setParLiberado(parAtual);
  }

  return (
    <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
      <Title>Interações</Title>
      <Muted>Checagem inicial e didática entre dois medicamentos. Não substitui bula profissional nem bases clínicas completas.</Muted>

      <Card>
        <Subtitle>1. Informe os dois medicamentos</Subtitle>
        <TextInput value={termoA} onChangeText={setTermoA} placeholder="Medicamento 1: ex. ibuprofeno" placeholderTextColor={theme.colors.muted} style={styles.input} autoCapitalize="none" autoCorrect={false} />
        <Candidato label="Selecionado 1" medicamento={medA} termo={termoA} />
        <TextInput value={termoB} onChangeText={setTermoB} placeholder="Medicamento 2: ex. varfarina" placeholderTextColor={theme.colors.muted} style={styles.input} autoCapitalize="none" autoCorrect={false} />
        <Candidato label="Selecionado 2" medicamento={medB} termo={termoB} />
      </Card>

      <Card>
        <Subtitle>Plano de uso</Subtitle>
        {premiumStatus.ativo ? (
          <Body>💎 Premium ativo: checagens ilimitadas neste aparelho.</Body>
        ) : (
          <Body>Grátis: {premiumStatus.consultasUsadas}/{premiumStatus.limiteGratis} consultas completas usadas. Restam {premiumStatus.consultasRestantes}.</Body>
        )}
        <Muted>Digitar e selecionar é livre. Ver o resultado completo da interação consome 1 consulta gratuita.</Muted>
        {!premiumStatus.ativo && premiumStatus.consultasRestantes === 0 ? <PrimaryButton title="Assinar Premium" onPress={() => onNavigate('premium')} variant="success" /> : null}
      </Card>

      <Card>
        <Subtitle>Como interpretar</Subtitle>
        <Body>Esta tela procura sinais simples: duplicidade de princípio ativo, anti-inflamatório com anticoagulante, soma de sedação, controle especial e riscos descritos na base local.</Body>
        <Muted>Se não aparecer alerta, ainda assim confira bula e dados do paciente antes da orientação final.</Muted>
      </Card>

      {resultado && !resultadoLiberado && (
        <Card>
          <Subtitle>Resultado pronto</Subtitle>
          <Body>Encontramos os dois medicamentos. Toque abaixo para liberar a checagem completa.</Body>
          {!premiumStatus.ativo ? <Muted>Esta ação usa 1 das 3 consultas gratuitas.</Muted> : <Muted>Premium ativo: não há limite de consultas.</Muted>}
          <PrimaryButton title="Ver checagem completa" onPress={liberarResultado} variant="primary" />
        </Card>
      )}

      {resultado && resultadoLiberado && (
        <Card>
          <Text style={[styles.badge, styles[resultado.nivel]]}>{rotuloNivel(resultado.nivel)}</Text>
          <Subtitle>{resultado.titulo}</Subtitle>
          <Section title="Alertas encontrados" items={resultado.alertas} />
          <Section title="Checklist obrigatório" items={resultado.checklist} />
        </Card>
      )}

      {!resultado && <Card><Body>Digite dois nomes para ver a checagem. O app usará o primeiro resultado encontrado na base local.</Body></Card>}
    </Screen>
  );
}

function Candidato({ label, medicamento, termo }: { label: string; medicamento?: Medicamento; termo: string }) {
  if (!termo.trim()) return <Muted>{label}: aguardando busca.</Muted>;
  if (!medicamento) return <Text style={styles.notFound}>{label}: não encontrado na base local.</Text>;
  return <Muted>{label}: {medicamento.nome} • {medicamento.principioAtivo}</Muted>;
}

function Section({ title, items }: { title: string; items: string[] }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {items.map((item, index) => <Text key={`${title}-${index}`} style={styles.item}>• {item}</Text>)}
    </View>
  );
}

function rotuloNivel(nivel: 'baixo' | 'atencao' | 'alto') {
  if (nivel === 'alto') return 'RISCO/ATENÇÃO ALTA';
  if (nivel === 'atencao') return 'ATENÇÃO';
  return 'BAIXO NA CHECAGEM INICIAL';
}

const styles = StyleSheet.create({
  input: { backgroundColor: theme.colors.card2, color: theme.colors.text, borderWidth: 1, borderColor: theme.colors.border, borderRadius: theme.radius.md, padding: 14, marginTop: 10, marginBottom: 8 },
  notFound: { color: theme.colors.red, lineHeight: 20 },
  badge: { alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, overflow: 'hidden', color: theme.colors.bg, fontWeight: '900', marginBottom: 8 },
  baixo: { backgroundColor: theme.colors.green },
  atencao: { backgroundColor: theme.colors.yellow },
  alto: { backgroundColor: theme.colors.red },
  section: { marginTop: 12 },
  sectionTitle: { color: theme.colors.text, fontWeight: '800', marginBottom: 4 },
  item: { color: theme.colors.muted, lineHeight: 20 }
});
