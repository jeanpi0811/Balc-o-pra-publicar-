import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { ActionTile } from '../components/ActionTile';
import { BottomTabs } from '../components/BottomTabs';
import { Card } from '../components/Card';
import { Screen } from '../components/Screen';
import { Body, Muted, Subtitle, Title } from '../components/TextBits';
import { appInfo } from '../data/appInfo';
import { ScreenName, tabFromScreen } from '../navigation';
import { theme } from '../styles/theme';

type Props = { onNavigate: (screen: ScreenName) => void; totalRegistros: number; activeScreen: ScreenName };

export function MaisScreen({ onNavigate, totalRegistros, activeScreen }: Props) {
  return (
    <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
      <Title>Mais</Title>
      <Muted>Informações do aplicativo, documentos, base local e opções complementares.</Muted>

      <Card>
        <Subtitle>Preferências de atendimento</Subtitle>
        <Body>A faixa etária é escolhida no começo de cada triagem: adulto, criança, idoso, gestante ou lactante.</Body>
        <Muted>Versão atual: registros e preferências ficam no aparelho. Sem login e sem servidor.</Muted>
      </Card>

      <ActionTile icon="🧾" title={`Registros (${totalRegistros})`} body="Histórico local dos atendimentos salvos." onPress={() => onNavigate('registro')} tone="green" />
      <ActionTile icon="🔁" title="Troca segura" body="Substituição com checklist de referência, genérico e similar." onPress={() => onNavigate('troca')} />
      <ActionTile icon="ℹ️" title="Sobre o app" body="Versão, responsável, finalidade e escopo de uso." onPress={() => onNavigate('sobre')} tone="muted" />
      <ActionTile icon="🔒" title="Privacidade" body="O que fica salvo, o que não é enviado e cuidados para publicação." onPress={() => onNavigate('privacidade')} tone="muted" />
      <ActionTile icon="📄" title="Termos de uso" body="Avisos e responsabilidade profissional." onPress={() => onNavigate('termos')} tone="muted" />
      <ActionTile icon="📚" title="Fontes e base" body="Origem dos dados, status de validação e atualização." onPress={() => onNavigate('fontes')} tone="muted" />
      <ActionTile icon="💎" title="Planos Pro" body="Assinatura oficial via App Store / Google Play, preparada para RevenueCat." onPress={() => onNavigate('premium')} tone="yellow" />

      <Card>
        <Subtitle>Responsável</Subtitle>
        <View style={styles.metaRow}><Text style={styles.metaLabel}>Nome</Text><Text style={styles.metaValue}>{appInfo.responsavelFarmaceutico}</Text></View>
        <View style={styles.metaRow}><Text style={styles.metaLabel}>Registro</Text><Text style={styles.metaValue}>{appInfo.registroProfissional}</Text></View>
        <View style={styles.metaRow}><Text style={styles.metaLabel}>Suporte</Text><Text style={styles.metaValue}>{appInfo.contatoSuporte}</Text></View>
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  metaRow: { flexDirection: 'row', gap: 10, justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: theme.colors.border, paddingVertical: 8 },
  metaLabel: { color: theme.colors.muted, fontWeight: '700', flex: 1 },
  metaValue: { color: theme.colors.text, flex: 2, textAlign: 'right' }
});
