import React, { useMemo, useState } from 'react';
import { Alert, TextInput, StyleSheet, Text, View, Pressable } from 'react-native';
import { BottomTabs } from '../components/BottomTabs';
import { Card } from '../components/Card';
import { PrimaryButton } from '../components/PrimaryButton';
import { Screen } from '../components/Screen';
import { Body, Muted, Subtitle, Title } from '../components/TextBits';
import { contarStatusValidacao, corStatusValidacao, rotuloStatusValidacao } from '../data/baseMedicamentosInfo';
import { medicamentos, origemMedicamentos, totalMedicamentosEnriquecidos } from '../data/medicamentos';
import { buscarMedicamentos } from '../logic/buscaMedicamentos';
import { ScreenName, tabFromScreen } from '../navigation';
import { theme } from '../styles/theme';
import { EnriquecimentoMedicamento, GrupoEspecialMedicamento, Medicamento } from '../types';
import { PremiumStatus } from '../storage/premium';

type Props = {
  onNavigate: (screen: ScreenName) => void;
  activeScreen: ScreenName;
  premiumStatus: PremiumStatus;
  onUsarConsultaCompleta: () => Promise<boolean>;
};

export function MedicamentosScreen({ onNavigate, activeScreen, premiumStatus, onUsarConsultaCompleta }: Props) {
  const [termo, setTermo] = useState('');
  const [selecionado, setSelecionado] = useState<string | null>(null);
  const encontrados = useMemo(() => buscarMedicamentos(medicamentos, termo).slice(0, termo.trim() ? 30 : 12), [termo]);
  const estatisticas = useMemo(() => contarStatusValidacao(medicamentos), []);

  async function alternarMedicamento(id: string) {
    if (selecionado === id) {
      setSelecionado(null);
      return;
    }

    const permitido = await onUsarConsultaCompleta();
    if (!permitido) {
      Alert.alert(
        'Limite gratuito atingido',
        'Você usou suas 3 consultas completas gratuitas. Assine o Premium para liberar consultas ilimitadas.',
        [
          { text: 'Agora não', style: 'cancel' },
          { text: 'Ver Premium', onPress: () => onNavigate('premium') },
        ]
      );
      return;
    }
    setSelecionado(id);
  }

  return (
    <Screen footer={<BottomTabs active={tabFromScreen(activeScreen)} onNavigate={onNavigate} />}>
      <Title>Medicamentos</Title>
      <Muted>Base local enriquecida para consulta, triagem e orientação. Não é prescrição: confira a bula do produto específico antes de orientar.</Muted>

      <Card>
        <Subtitle>Como usar nesta tela</Subtitle>
        <Step text="Busque por nome, princípio ativo, classe, risco, grupo especial ou interação." />
        <Step text="Leia primeiro o resumo leigo e depois o checklist profissional." />
        <Step text="Use os grupos especiais para decidir se pode orientar, se exige cautela ou encaminhamento." />
        <Step text="Quando a base indicar pendência, confirme no Bulário/Sistema de Consultas antes de validar." />
        <View style={styles.statsRow}>
          <Pill label="Enriquecidos" value={totalMedicamentosEnriquecidos} tone="green" />
          <Pill label="Pré-validados" value={estatisticas.pre_validado} tone="green" />
          <Pill label="Parciais" value={estatisticas.parcial} tone="yellow" />
          <Pill label="Pendentes" value={estatisticas.pendente} tone="muted" />
        </View>
        <Muted>{origemMedicamentos}</Muted>
      </Card>

      <Card>
        <Subtitle>Plano de uso</Subtitle>
        {premiumStatus.ativo ? (
          <Body>💎 Premium ativo: consultas completas ilimitadas neste aparelho.</Body>
        ) : (
          <Body>Grátis: {premiumStatus.consultasUsadas}/{premiumStatus.limiteGratis} consultas completas usadas. Restam {premiumStatus.consultasRestantes}.</Body>
        )}
        <Muted>Pesquisar é livre. Abrir o resumo completo de um medicamento consome 1 consulta gratuita.</Muted>
        {!premiumStatus.ativo && premiumStatus.consultasRestantes === 0 ? <PrimaryButton title="Assinar Premium" onPress={() => onNavigate('premium')} variant="success" /> : null}
      </Card>

      <TextInput
        value={termo}
        onChangeText={(v) => { setTermo(v); setSelecionado(null); }}
        placeholder="Ex: ibuprofeno, gestante, anticoagulante, QT, refluxo..."
        placeholderTextColor={theme.colors.muted}
        style={styles.input}
        autoCapitalize="none"
        autoCorrect={false}
      />
      <Muted>{encontrados.length} resultado(s) exibido(s). Refine a busca para filtrar melhor.</Muted>

      {encontrados.map((medicamento) => (
        <MedicamentoCard
          key={medicamento.id}
          medicamento={medicamento}
          aberto={selecionado === medicamento.id}
          onToggle={() => alternarMedicamento(medicamento.id)}
        />
      ))}

      {encontrados.length === 0 && <Card><Body>Nenhum medicamento encontrado na base local.</Body></Card>}
      <PrimaryButton title="Checar interação entre dois medicamentos" onPress={() => onNavigate('interacoes')} variant="secondary" />
      <PrimaryButton title="Troca segura" onPress={() => onNavigate('troca')} variant="secondary" />
    </Screen>
  );
}

function MedicamentoCard({ medicamento, aberto, onToggle }: { medicamento: Medicamento; aberto: boolean; onToggle: () => void }) {
  const statusColor = statusStyle(corStatusValidacao(medicamento.statusValidacao));
  const e = medicamento.enriquecimento;
  return (
    <Card>
      <Pressable onPress={onToggle}>
        <Subtitle>{medicamento.nome}</Subtitle>
        <Muted>{medicamento.principioAtivo} • {medicamento.classe}</Muted>
        <Body>{e?.uso_orientativo.para_que_serve ?? `${medicamento.forma} — ${medicamento.dosagem}`}</Body>
        <View style={styles.tagRow}>
          <Text style={styles.tag}>{medicamento.tarja}</Text>
          <Text style={[styles.statusTag, statusColor]}>{rotuloStatusValidacao(medicamento.statusValidacao)}</Text>
          {e ? <Text style={styles.enrichedTag}>base enriquecida</Text> : null}
        </View>
        <Muted>{aberto ? 'Toque para recolher.' : 'Toque para abrir resumo, grupos especiais, interações e fontes.'}</Muted>
      </Pressable>

      {aberto && (
        <View>
          {e ? <EnriquecidoSection enriquecimento={e} /> : <Section title="Base enriquecida" items={["Este item ainda não tem enriquecimento clínico estruturado."]} />}

          <Section title="Identificação original" items={[
            medicamento.numeroRegistroAnvisa ? `Registro Anvisa: ${medicamento.numeroRegistroAnvisa}` : 'Registro Anvisa não informado nesta base.',
            medicamento.situacaoRegistro ? `Situação: ${medicamento.situacaoRegistro}` : 'Situação não informada.',
            medicamento.detentorRegistro ? `Detentor: ${medicamento.detentorRegistro}` : 'Detentor não informado.',
            medicamento.referencia ? `Referência: ${medicamento.referencia}` : 'Referência não cadastrada.',
            `Forma/apresentação: ${medicamento.forma}`,
            `Dosagem: ${medicamento.dosagem}`
          ]} />
          <Section title="Antes de orientar" items={medicamento.perguntasChave ?? []} empty="Sem perguntas-chave cadastradas." />
          <Section title="Alertas originais" items={medicamento.alertas} empty="Sem alerta cadastrado nesta base." />
          <Section title="Contraindicações/cuidados originais" items={medicamento.contraindicacoes} empty="Sem contraindicação cadastrada nesta base." />
          <Section title="Quando encaminhar" items={medicamento.quandoEncaminhar ?? []} empty="Sem critério de encaminhamento cadastrado." />
          <Section title="Validação" items={[
            medicamento.escopoValidacao ? `Escopo: ${medicamento.escopoValidacao}` : 'Escopo não informado.',
            medicamento.bulaProfissionalConferida ? 'Bula profissional: conferida.' : 'Bula profissional: pendente para produto específico.',
            medicamento.revisaoVenceEm ? `Revisão vence em: ${medicamento.revisaoVenceEm}` : 'Sem vencimento de revisão informado.',
            ...(medicamento.observacoesValidacao ?? [])
          ]} />
          <FonteSection medicamento={medicamento} enriquecimento={e} />
        </View>
      )}
    </Card>
  );
}

function EnriquecidoSection({ enriquecimento }: { enriquecimento: EnriquecimentoMedicamento }) {
  return (
    <View>
      <Section title="Resumo para leigos" items={[
        `Para que serve: ${enriquecimento.resumo_leigo.para_que_serve}`,
        `Quando ter cuidado: ${enriquecimento.resumo_leigo.quando_ter_cuidado}`,
        `Quando procurar atendimento: ${enriquecimento.resumo_leigo.quando_procurar_atendimento}`,
        `O que não fazer: ${enriquecimento.resumo_leigo.o_que_nao_fazer}`
      ]} />

      <Section title="Uso orientativo" items={[
        enriquecimento.uso_orientativo.indicacao_geral,
        enriquecimento.uso_orientativo.observacao_nao_prescritiva
      ]} />

      <Section title="Grupos especiais" items={formatarGrupos(enriquecimento)} />
      <Section title="Checklist de triagem" items={[
        ...enriquecimento.triagem_farmaceutica.perguntas_obrigatorias,
        ...enriquecimento.triagem_farmaceutica.perguntas_recomendadas
      ]} />
      <Section title="Cuidados e sinais de alerta" items={[
        ...enriquecimento.alertas.cuidados,
        ...enriquecimento.alertas.sinais_alerta,
        ...enriquecimento.alertas.quando_encaminhar
      ]} />
      <Section title="Efeitos adversos" items={[
        ...prefixar('Comuns', enriquecimento.efeitos_adversos.comuns),
        ...prefixar('Importantes', enriquecimento.efeitos_adversos.importantes),
        ...prefixar('Alergia', enriquecimento.efeitos_adversos.alergia),
        ...prefixar('Intoxicação', enriquecimento.efeitos_adversos.intoxicacao),
        ...prefixar('Atendimento imediato', enriquecimento.efeitos_adversos.atendimento_imediato)
      ]} />
      <Section title="Interações relevantes" items={enriquecimento.interacoes.map((i) => `${i.gravidade.toUpperCase()} — ${i.com}: ${i.consequencia} Orientação: ${i.orientacao_segura}`)} empty="Sem interação relevante cadastrada nesta base." />
      <Section title="Responsabilidade" items={[enriquecimento.aviso_responsabilidade]} />
      <Section title="Pendências de validação" items={[
        enriquecimento.status_validacao.validado ? 'Marcado como validado.' : 'Ainda não marcado como validado final.',
        ...enriquecimento.status_validacao.pendencias,
        enriquecimento.status_validacao.observacoes
      ]} />
    </View>
  );
}

function formatarGrupos(enriquecimento: EnriquecimentoMedicamento) {
  const grupos: Array<[string, GrupoEspecialMedicamento]> = [
    ['Crianças', enriquecimento.grupos_especiais.criancas],
    ['Idosos', enriquecimento.grupos_especiais.idosos],
    ['Gestantes', enriquecimento.grupos_especiais.gestantes],
    ['Lactantes', enriquecimento.grupos_especiais.lactantes],
    ['Doença renal', enriquecimento.grupos_especiais.renal],
    ['Doença hepática', enriquecimento.grupos_especiais.hepatica],
    ['Hipertensão', enriquecimento.grupos_especiais.hipertensao],
    ['Diabetes', enriquecimento.grupos_especiais.diabetes],
    ['Cardiopatia', enriquecimento.grupos_especiais.cardiopatia],
    ['Anticoagulantes', enriquecimento.grupos_especiais.anticoagulantes],
    ['Alergias', enriquecimento.grupos_especiais.alergias]
  ];
  return grupos.map(([nome, grupo]) => `${nome}: ${grupo.classificacao}. ${grupo.observacao}`);
}

function prefixar(prefixo: string, itens: string[]) {
  return itens.map((item) => `${prefixo}: ${item}`);
}

function FonteSection({ medicamento, enriquecimento }: { medicamento: Medicamento; enriquecimento?: EnriquecimentoMedicamento }) {
  const fontesOriginais = medicamento.fontes ?? [];
  const fontesEnriquecidas = enriquecimento?.fontes ?? [];
  if (fontesOriginais.length === 0 && fontesEnriquecidas.length === 0) return <Section title="Fontes" items={["Fonte não cadastrada. Não usar como informação clínica final."]} />;
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>Fontes</Text>
      {fontesEnriquecidas.map((fonte, index) => (
        <Text key={`${medicamento.id}-fonte-e-${index}`} style={styles.item}>• {fonte.nome} — acesso {fonte.data_acesso} — confiança {fonte.nivel_confianca}. {fonte.resumo_usado}</Text>
      ))}
      {fontesOriginais.map((fonte, index) => (
        <Text key={`${medicamento.id}-fonte-${index}`} style={styles.item}>• {fonte.tipo}: {fonte.titulo}{fonte.acessadoEm ? ` — acesso ${fonte.acessadoEm}` : ''}{fonte.observacao ? ` — ${fonte.observacao}` : ''}</Text>
      ))}
    </View>
  );
}

function Section({ title, items, empty = 'Não informado.' }: { title: string; items: string[]; empty?: string }) {
  const list = items.filter(Boolean);
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {list.length === 0 ? <Text style={styles.item}>• {empty}</Text> : list.map((item, index) => <Text key={`${title}-${index}`} style={styles.item}>• {item}</Text>)}
    </View>
  );
}

function Step({ text }: { text: string }) { return <Text style={styles.step}>• {text}</Text>; }
function Pill({ label, value, tone }: { label: string; value: number; tone: 'green' | 'yellow' | 'red' | 'muted' }) { return (<View style={styles.pill}><Text style={[styles.pillValue, statusStyle(tone)]}>{value}</Text><Text style={styles.pillLabel}>{label}</Text></View>); }
function statusStyle(tone: 'green' | 'yellow' | 'red' | 'muted') { if (tone === 'green') return { color: theme.colors.green }; if (tone === 'yellow') return { color: theme.colors.yellow }; if (tone === 'red') return { color: theme.colors.red }; return { color: theme.colors.muted }; }

const styles = StyleSheet.create({
  input: { backgroundColor: theme.colors.card, color: theme.colors.text, borderWidth: 1, borderColor: theme.colors.border, borderRadius: theme.radius.md, padding: 14, marginVertical: 14 },
  tagRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 10, marginBottom: 8 },
  tag: { color: theme.colors.bg, backgroundColor: theme.colors.primary, alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999, overflow: 'hidden', fontWeight: '800' },
  enrichedTag: { color: theme.colors.bg, backgroundColor: theme.colors.green, alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999, overflow: 'hidden', fontWeight: '800' },
  statusTag: { backgroundColor: theme.colors.card2, borderColor: theme.colors.border, borderWidth: 1, alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999, overflow: 'hidden', fontWeight: '800' },
  section: { marginTop: 12 },
  sectionTitle: { color: theme.colors.text, fontWeight: '800', marginBottom: 4 },
  item: { color: theme.colors.muted, lineHeight: 20 },
  statsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  pill: { backgroundColor: theme.colors.card2, borderWidth: 1, borderColor: theme.colors.border, borderRadius: theme.radius.md, padding: 8, minWidth: '46%', flexGrow: 1, marginBottom: 8 },
  pillValue: { fontWeight: '900', fontSize: 20, textAlign: 'center' },
  pillLabel: { color: theme.colors.muted, textAlign: 'center', fontSize: 11, marginTop: 2 },
  step: { color: theme.colors.muted, lineHeight: 20, marginBottom: 4 }
});
